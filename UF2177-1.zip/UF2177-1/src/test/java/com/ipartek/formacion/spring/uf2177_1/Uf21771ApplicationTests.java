package com.ipartek.formacion.spring.uf2177_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uf21771ApplicationTests {

	@Test
	void contextLoads() {
	}

}
