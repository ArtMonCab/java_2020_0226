INSERT INTO medicamentos (referencia, nombre, precio) VALUES
('123456789012', 'Paracetamol', 3.54),
('123456789013', 'Hiburprofeno', 2.86),
('123456789014', 'Aspirina', 8.35);