package com.ipartek.formacion.spring.UF21773.repositorio;

public interface Dao<T> {
	Iterable<T> obtenerTodos();
}
