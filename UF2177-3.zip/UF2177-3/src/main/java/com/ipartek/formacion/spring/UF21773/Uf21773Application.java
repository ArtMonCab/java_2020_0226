package com.ipartek.formacion.spring.UF21773;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Uf21773Application {

	public static void main(String[] args) {
		SpringApplication.run(Uf21773Application.class, args);
	}

}
