package com.ipartek.formacion.spring.UF21773;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uf21773ApplicationTests {

	@Test
	void contextLoads() {
	}

}
