package com.ipartek.formacion.spring.MF0226_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mf02263Application {

	public static void main(String[] args) {
		SpringApplication.run(Mf02263Application.class, args);
	}

}
