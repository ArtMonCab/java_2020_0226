package com.ipartek.formacion.spring.MF0226_3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mf02263ApplicationTests {

	@Test
	void contextLoads() {
	}

}
