package com.ipartek.formacion.spring.uf2177_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uf21772ApplicationTests {

	@Test
	void contextLoads() {
	}

}
